
function progress(){

	console.log("Progressing");
	document.getElementById("convertForm").submit();

}

document.addEventListener('load', progress, true);